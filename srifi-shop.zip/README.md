SRIFI SHOP - Vite React + Tailwind demo

How to run locally:
1. npm install
2. npm run dev
Open http://localhost:5173

Notes for Vercel deployment:
- Upload this project folder / zip to Vercel import.
- Vercel will run `npm install` and `npm run build` automatically.
- Build output directory: `dist` (Vite default)

Customize:
- Edit `src/App.jsx` to change products, text, and styles.
- Tailwind is already configured.
